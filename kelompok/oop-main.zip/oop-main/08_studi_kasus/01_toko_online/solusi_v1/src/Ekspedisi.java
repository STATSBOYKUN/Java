public class Ekspedisi {
    private String nama;

    Ekspedisi(String nama){
        this.nama = nama;
    }

    public double hitungOngkir(String asal, String tujuan, double berat){
        return 1.1;
    }
}
