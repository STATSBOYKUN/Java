class Employee extends Person {
    int salary;
    
    void work() {
       System.out.println("Saya bekerja dan mendapat gaji sebesar " + salary + " dollar.");
    }
 }
