class Person {
    String name;
    int age;
    
    void introduce() {
       System.out.println("Nama saya " + name + ", umur saya " + age + " tahun.");
    }
 }
 