class Student extends Person {
    String major;
    
    void study() {
       System.out.println("Saya sedang belajar di jurusan " + major + ".");
    }
 }