class Shape {
    String color;
    
    Shape(String color) {
       this.color = color;
    }
    
    double getArea() {
       System.out.println("Error: getArea() belum diimplementasikan.");
       return 0;
    }
 }
 