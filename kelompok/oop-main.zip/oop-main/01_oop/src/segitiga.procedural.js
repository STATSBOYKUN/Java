function hitungLuasSegitiga(alas, tinggi) {
    return 0.5 * alas * tinggi;
  }
  
  const alas = 10;
  const tinggi = 5;
  const luasSegitiga = hitungLuasSegitiga(alas, tinggi);
  console.log(luasSegitiga); // Output: 25